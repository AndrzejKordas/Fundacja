<?php get_header(); ?>
    <div class="slider">

    </div>
    <div class="container">

        <div class="row kolumny">
            <div class="col-md-4">
                <h3>Wydarzenia <i class="fa fa-bullhorn" style="font-size:24px;color:pink"></i></h3>
                <p>Apparently we had reached a great height in the atmosphere, for the sky was a dead black, and the stars had ceased to twinkle. By the same illusion which lifts the horizon</p>
                <a href="#">MORE</a>
            </div>
            <div class="col-md-4">
                <h3>Nasze cele <i class="fa fa-heart-o" style="font-size:24px;color:pink"></i></h3>
                <p>Apparently we had reached a great height in the atmosphere, for the sky was a dead black,</p>
                <a href="#">MORE</a>
            </div>
            <div class="col-md-4">
                <h3>Darczyńcy <i class="fa fa-bar-chart" style="font-size:24px;color:pink"></i></h3>
                <p>Apparently we had reached a great height in the atmosphere, for the sky was a dead black, and the stars had ceased to twinkle. By the same illusion</p>
                <a href="#">MORE</a>
            </div>
        </div>


    </div>
    <div class="pasek">
        <div class="container">
            <div class="row justify-content-center">
                <h1>O nas</h1>
                Szanowni Państwo Pomysł na założenie fundacji powstał w wyniku własnych doświadczeń życiowych, ponieważ sama borykałam się z próchnicą i chorobami jamy ustnej doskonale wiem jak trudny, wstydliwy oraz kosztowny jest to problem.
                <a href="#">MORE</a>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row justify-content-center">
            <h1>Kontakt</h1>
        </div>

        <form>
            <div class="row">
                <div class="form-group col-md-6">
                    <input type="text" class="form-control" placeholder="Nazwisko">
                </div>
                <div class="form-group col-md-6">
                    <input type="text" class="form-control" placeholder="Telefon">
                </div>
                <div class="form-group col-md-6">
                    <input type="text" class="form-control" placeholder="email">
                </div>
                <div class="form-group col-md-6">
                    <input type="text" class="form-control" placeholder="Temat">
                </div>
                <div class="form-group col-md-12">
                    <textarea class="form-control" placeholder="Treść"></textarea>
                </div>
            </div>
            <div class="row justify-content-center">
                <button type="submit" class="btn btn-dark" style="padding:8px 40px">Wyślij</button>
            </div>
        </form>
    </div>
  <?php get_footer(); ?>