  <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h3>Linki</h3>
                    <li>
                        <a href="#">O nas </a>
                    </li>
                    <li>
                        <a href="#">Nasze cele</a>
                    </li>
                    <li>
                        <a href="#">Wydarzenia</a>
                    </li>
                    <li>
                        <a href="#">Statut</a>
                    </li>
                    <li>
                        <a href="#">Darczyńcy</a>
                    </li>
                    <li>
                        <a href="#">Kontakt</a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-facebook-square" style="color:#fff;font-size:48px"></i></a>
                    </li>
                </div>
                <div class="col-md-4">
                    <h3>Dane firmy</h3>
                    <div>Władze Fundacji Prezes Aneta Wilczyńska</div>
                    <p>Ul. Wschodnia 101<br/> 21-302 Kąkolewnica<br/> woj. lubelskie , powiat Radzyń Podlaski</p>
                </div>
                <div class="col-md-4 stopkaLewa">
                    <h3>Kontakt z fundacją</h3>
                    <p>tel. 511-892-975 Aneta Wilczyńska<br/> </p>
                    <div>numer konta i KRS<br/><strong> nr. konta : 6720 3000 4511 1000 0003334050</strong> Bank Gospodarki Żywnościowej S.A. VIII Oddział Warszawa ul. Puławska 29 ,01-211 Warszawa ul. Kasprzaka 10/16<br/> KRS : 0000495121</div>
                    
                </div>
            </div>
        </div>
    </footer>

<?php wp_footer ?>
</body>

</html>
